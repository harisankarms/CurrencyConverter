package com.ty.currencyconverter.exception;

public class CurrencyException extends RuntimeException {
    public CurrencyException(String message) {
        super(message);
    }
}
